/** @type {import('tailwindcss').Config} */
export default {
    content: [
      "./index.html",
      "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
      extend: {
        colors: {
          'usac-blue': '#1e3a8a', 
          'usac-gold': '#b59410',
        },
      },
    },
    plugins: [],
  }